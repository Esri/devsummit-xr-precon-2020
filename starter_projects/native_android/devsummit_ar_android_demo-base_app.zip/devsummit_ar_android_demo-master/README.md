# devsummit_ar_android_demo
It may be helpful to observe the commit messages to see how we go from an empty project to enabling the project to work the ArcGISRuntime Android toolkit to creating flyover, tabletop, and world scale AR apps.

The code in Master shows what is necessary to get the ArcGISARView into your app.

The code in the flyover branch includes the code in master + a commit that makes the app a Flyover app.

The code in the tabletop branch includes the code in master + a commit that makes the app a Tabletop app.

The code in the worldscale branch includes the code in master + a commit that makes the app a World Scale app.
